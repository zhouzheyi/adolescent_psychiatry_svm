function [PredictedScore,All_SelectedF,All_SelectedW,SelectedFeaturesNum] = Func_Loocv_Predicts_Behavior(X_Features,Y_score,SIDs,p_th,Para)

% function, leave-one-out cross-validation
% Process: feature selection, model construction and prediction
% Input:
% X_Features: all the features, SubsNum* FeatureNums
% Y_score: The target label, SubNum*1;
% p_th: threshold used to selecte features

% Output:
% All_SelectedF:Selected Features in each LOOCV
% All_SelectedW: weight for each selected features

addpath(genpath('/home/indi/Tools/libsvm-3.20'));


indorder = [1:length(SIDs)];
All_SelectedF = zeros(length(SIDs),size(X_Features,2));
All_SelectedW = zeros(length(SIDs),size(X_Features,2));

for s = 1:length(SIDs)
    fprintf('\n Leaving out subj # %6.3f',s);
    
    ind_test = s;
    ind_train = indorder;
    ind_train(s) = [];

     X_train = X_Features(ind_train,:);
     Y_train = Y_score(ind_train,:);

     X_test = X_Features(ind_test,:);
     Y_test = Y_score(ind_test,:);

     % Feature selection
   
    
    [R,P] = corr(Y_train,X_train);

    ind = find(P<p_th);
    
%     X_train = demean(X_train(:,ind),2);    
%     X_test = demean(X_test(:,ind),2);
%    
    X_train = X_train(:,ind);    
    X_test = X_test(:,ind);
% %    


    All_SelectedF(s,ind) = 1;


    % Model Construction
   %c = max(Y_train)-min(Y_train); % -s 3 t 0
%      c = 1;
  
    %Para = ['-s 3 -p 0.01 -t 0 -c ' num2str(c)];
    %Para = ['-s 0 -t 0'];
 
 
    model = svmtrain(Y_train,X_train,Para);
    %All_SelectedW(s,ind) = model.SVs'*model.sv_coef; %weight for each selected connectivity
    
     % Prediction    
     PredictedScore(s,1) = svmpredict(Y_test,X_test,model);
%      
    
   SelectedFeaturesNum(s) = length(ind);
   
   
   
    % Liblinear
%     cmd = ['-s 13 -c ' num2str(c)];% s: default 1
%     model = train(Y_train, sparse(X_train),cmd);
% 
%     [~,~,PredictedScore(s,1)] = predict(Y_test, sparse(X_test), model);
   
   
end



