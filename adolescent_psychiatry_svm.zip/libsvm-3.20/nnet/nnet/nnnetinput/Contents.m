% Neural Network Toolbox Net Input Functions.
%
%   netprod - Product net input function.
%   netsum  - Sum net input function.
%
% <a href="matlab:help nnet/Contents.m">Main nnet function list</a>.
 
% Copyright 1992-2010 The MathWorks, Inc.
