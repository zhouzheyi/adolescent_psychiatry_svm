function input = nn_configure_input_only(input,x)

% Copyright 2010 The MathWorks, Inc.

