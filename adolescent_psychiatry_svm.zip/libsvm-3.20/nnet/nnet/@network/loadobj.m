function net = loadobj(obj)
%LOADOBJ Load a network object.
%
%  <a href="matlab:doc loadobj">loadobj</a>(NET) is automatically called with a structure when
%  a network is loaded from a MAT file.  If the network is from a
%  previous version of Neural Network Toolbox software then
%  it is updated to the latest version.

% Copyright 1992-2011 The MathWorks, Inc.
% $Revision: 1.4.4.3 $ $Date: 2011/05/09 01:00:36 $

if isa(obj,'network')
  net = obj;
else
  net = network(nnupdate.net(obj));
end
