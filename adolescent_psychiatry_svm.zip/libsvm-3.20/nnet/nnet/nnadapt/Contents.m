% Neural Network Toolbox Adapt Functions.
%
%   adaptwb - Sequential order incremental training w/learning functions.
%
% <a href="matlab:help nnet/Contents.m">Main nnet function list</a>.
 
% Copyright 1992-2010 The MathWorks, Inc.
