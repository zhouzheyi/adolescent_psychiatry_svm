%

% This file intentionally left blank.
% This allows HELP NNET to show TOOLBOX/NNET/CONTENTS.M
% without generating extraneous help from TOOLBOX/NNET/NNET/CONTENTS.M

% Copyright 1992-2010 The MathWorks, Inc.