%NNCUSTOM List of functions to use as templates for custom functions
%
% WARNING: Custom functions may need to be updated to remain compatible
% with future versions of Neural Network Toolbox software.
%
% The following functions can be used as templates for the corresponding
% types of functions:
%
% Neural Network Creation
%   feedforwardnet - Network creation function
%
% Neural Network Training and Adaption
%   mse - Performance function
%   dividerand - Data division function
%   traingd - Network training function
%   btderiv - Network derivative function
%   initlay - Network initialization function
%   srchbac - Training search function
%   adapt - Network adaption function
%   plotfit - Plot function
%
% Input and Output Functions
%  mapminmax - Data pre-pocessing function
%
% Neuron Layer Functions
%  tansig - Transfer function
%  netsum - Net input function
%  dist - Layer distance function
%  initwb - Layer initialiation function
%  hextop - Layer topology function
%
% Weight and Bias Functions
%  dotprod - Weight function
%  randnc - Weight initialization function
%  learngd - Weight learning function
%
% WARNING: Custom functions may need to be updated to remain compatible
% with future versions of Neural Network Toolbox software.
