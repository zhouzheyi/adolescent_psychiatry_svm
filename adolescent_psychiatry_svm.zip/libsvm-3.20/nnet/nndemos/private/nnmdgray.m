function c = nnmdgray
%NNMDGRAY Neural Network Design utility function.

% $Revision: 1.6 $
% Copyright 1994-2002 PWS Publishing Company and The MathWorks, Inc.
% First Version, 8-31-95.

%==================================================================

c = [0.55 0.55 0.55];
