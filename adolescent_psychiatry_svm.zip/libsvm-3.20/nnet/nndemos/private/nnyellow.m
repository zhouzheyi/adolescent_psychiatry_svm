function c = nnyellow
%NNYELLOW Yellow used by Neural Network Toolbox GUI.
  
%  NNYELLOW returns rgb triple for yellow.

% Mark Beale 6-4-94
% Copyright 1994-2002 PWS Publishing Company and The MathWorks, Inc.
% $Revision: 1.7 $

c = [1 1 0];
